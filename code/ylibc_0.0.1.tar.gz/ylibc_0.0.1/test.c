#define Y_IMPLEMENTATION
#include "y.h"

#include <stdio.h>

void string_run_all(); /* src/string.c */
void misc_run_all();   /* src/misc.c   */

int main() {
    string_run_all();
    misc_run_all();
    printf("All tests finished!\n");
    return 0;
}

