/* One-file C89 library by yobibyte.
 *
 * Copyright 2026 Vitaly Kurin (yobibyte)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of
 * this software and associated documentation files (the “Software”), to deal in
 * the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
 * of the Software, and to permit persons to whom the Software is furnished to do
 * so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED “AS IS”, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

/* How to use:
 * - Copy y.h to your project.
 * - Include y.h in every file that needs it.
 * - Add `#define Y_IMPLEMENTATION` to *only* one file!
 */

/* What does this library have (treat this as the table of contents):
 * - containers:
 * - strings
 * - misc:
 * - hashing
 */

#ifndef Y_H
#define Y_H

#define Y_VERSION 0.0.1

#include <stddef.h>
#include <stdlib.h>
#include <string.h>

/* strings */
char *y_strdup(const char *str); /* Dupe a given null-terminated str. */
char *y_strcat(const char *left, const char *right); /* Concat two strings, new memory is returned, left/rigtht are not freed */
size_t y_strlen(const char *str); /* Get the length of a null-terminated str. */
/* end of strings */

/* misc */
#define Y_FNV_BASIS 0x811c9dc5
#define Y_FNV_PRIME 0x01000193
size_t y_hash_fnv1a(char *str); /* Get an FNV-1A hash of a string. */
/* end of misc */


#ifdef Y_IMPLEMENTATION

/* strings impl */
char *y_strdup(const char *str) {
    size_t len = y_strlen(str);
    char *copy = malloc(len+1);
    if (!copy) {
        return NULL;
    }
    memcpy(copy, str, len + 1);
    return copy;
}

char *y_strcat(const char *left, const char *right) {
    size_t left_len  = y_strlen(left);
    size_t right_len = y_strlen(right);
    /* +1 because we will only need \0 from the right string. */
    char *res = malloc(left_len + right_len + 1);
    if (!res) {
        return NULL;
    }
    memcpy(res, left, left_len);
    memcpy(res + left_len, right, right_len + 1);
    return res;
}

size_t y_strlen(const char *str) {
    size_t len = 0;
    while(str[len] != '\0') {
        len++;
    }
    return len;
}
/* end of strings impl */

/* misc impl */
/* Fowler-Noll-Vo 1A hash function.
 * Start with a fixed number, go over data byte by byte and modify the hash.
 * https://en.wikipedia.org/wiki/Fowler%E2%80%93Noll%E2%80%93Vo_hash_function
 */
size_t y_hash_fnv1a(char *str) {
    size_t hash = Y_FNV_BASIS;
    while (*str) {
        hash ^= *str++;
        hash *= Y_FNV_PRIME;
    }
    return hash;
}
/* end of misc impl */
#endif /* implementation */
#endif /* Y_H */
