#include <assert.h>
#include "../y.h"

void test_empty_hash() {
    assert(y_hash_fnv1a("") == Y_FNV_BASIS);
}

void misc_run_all() {
    test_empty_hash();
}
