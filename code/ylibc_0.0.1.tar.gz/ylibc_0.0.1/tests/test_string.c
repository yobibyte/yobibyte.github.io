#include <assert.h>
#include <stdlib.h>
#include <string.h> 
#include "../y.h"

void test_dupe_string() {
    char *dupe = y_strdup("123");
    assert (strlen(dupe) == 3);
    assert (dupe[4] == '\0');
    free(dupe);
}

void test_strlen() {
    assert (y_strlen("abc") == 3);
    assert (y_strlen("a") == 1);
    assert (y_strlen("") == 0);
}

void test_strcat() {
    char *left = "abc";
    char *right = "42";
    char *cat = y_strcat(left, right);
    assert (y_strlen(cat) == 5);
    /* Replace when we add strcmp. */
    assert (cat[0] == 'a');
    assert (cat[1] == 'b');
    assert (cat[2] == 'c');
    assert (cat[3] == '4');
    assert (cat[4] == '2');
    assert (cat[5] == '\0');
}

void string_run_all() {
    test_dupe_string();
    test_strlen();
}

